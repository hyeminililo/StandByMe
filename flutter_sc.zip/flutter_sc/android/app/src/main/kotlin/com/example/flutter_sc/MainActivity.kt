package com.example.flutter_sc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
