enum LoginPlatform {
  google,
  none, // logout
}

LoginPlatform _loginPlatform = LoginPlatform.none;