import 'package:flutter/material.dart';

const PRIMARYCOLOR = Color.fromARGB(255, 174, 226, 229); // 민트

const MAIN_TEXT_COLOR = Color(0xFFFFFFFF); // 화이트

const BODY_TEXT_COLOR = Color(0x00000000); // 블랙

const SHADOW_TEXT_COLOR = Color(0x008C8888);

const BASE_COLOR = Color(0x008C8888);

Padding padding = const Padding(padding: EdgeInsets.only(top: 20));
